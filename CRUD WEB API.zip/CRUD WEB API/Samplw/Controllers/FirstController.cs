﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace Samplw.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class FirstController : ControllerBase
    {
        /////////////  ----  FOR __ INSERT ----  //////////////
        [HttpPost]
    [Route("students")]
        public int students(SampleModel model)
        {
            string constring = "Data source=(localDb)\\MSSQLLOCALDB; initial catalog=registration; integrated security=SSPI";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "Insert into regtable(name,Email,Contact,gender,HighestQualification) " +
                " values(@name,@Email,@Contact,@Gender,@HighestQualification)";
            cmd.Parameters.AddWithValue("@name", model.name);
            cmd.Parameters.AddWithValue("@Email", model.Email);
            cmd.Parameters.AddWithValue("@Contact", model.Contact);
            cmd.Parameters.AddWithValue("@Gender", model.gender);
            cmd.Parameters.AddWithValue("@HighestQualification", model.HighestQualification);
            //cmd.Parameters.AddWithValue("@UId", model.User_id);
        

            int n = cmd.ExecuteNonQuery();
            con.Close();
            return n;
        }
        ///////////  ----  FOR __ READ \ SELECT  ----  //////////////
        [Route("Employees")]
        [HttpGet]
        public List<SampleModel> Employees()
        {
            List<SampleModel> models = new List<SampleModel>();
            string constring = "data source=(localDb)\\MSSQLLOCALDB; initial catalog=registration; integrated security=SSPI";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "select *  from regtable ";
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                SampleModel emp = new SampleModel();
                emp.name = dr["name"] == DBNull.Value ? "" : dr["name"].ToString();
                emp.Email = dr["Email"] == DBNull.Value ? "" : dr["Email"].ToString();
                emp.Contact = dr["Contact"] == DBNull.Value ? "" : dr["Contact"].ToString();
                emp.gender = dr["Gender"] == DBNull.Value ? "" : dr["Gender"].ToString();
                emp.HighestQualification = dr["HighestQualification"] == DBNull.Value ? "" : dr["HighestQualification"].ToString();
                emp.User_id = dr["USer_Id"] == DBNull.Value ? 0 : Convert.ToInt32(dr["USer_Id"]);
                models.Add(emp);

            }

            return models;

        }
        /////////////  ----  FOR __ UPDATE  ----  //////////////
        [Route("utpal")]
        [HttpPut]
        public int UpdateData2(SampleModel model)
        {
            string constring = "data source=(localDb)\\MSSQLLOCALDB; initial catalog=registration; integrated security=SSPI";

            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.Connection = con;

            cmd.CommandText = "UPDATE regtable " +
                "SET name = @name, Email = @Email, Contact = @contact, " +
                "gender = @gender,HighestQualification=@HighestQualification WHERE User_id = @user_id";

            cmd.Parameters.AddWithValue("@name", model.name);
            cmd.Parameters.AddWithValue("@Email", model.Email);
            cmd.Parameters.AddWithValue("@Contact", model.Contact);
            cmd.Parameters.AddWithValue("@gender", model.gender);
            cmd.Parameters.AddWithValue("@HighestQualification", model.HighestQualification);
            cmd.Parameters.AddWithValue("@user_id", model.User_id);

            int n = cmd.ExecuteNonQuery();

            con.Close();
            return n;

        }

        /////////////  ----  FOR __ DELETE  ----  //////////////
        [Route("Gaurav")]
        [HttpDelete]
        public int DeleteData2(SampleModel model)
        {
            string constring = "data source=(localDb)\\MSSQLLOCALDB; initial catalog=registration; integrated security = SSPI";

            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.Connection = con;

            cmd.CommandText = " Delete from regtable " +
                "where Email= @Email ";
            cmd.Parameters.AddWithValue("@Email", model.Email);
            int n = cmd.ExecuteNonQuery();
            con.Close();
            return n;

        }
    }
}