﻿namespace Samplw
{
    public class SampleModel
    {
        public string name { get; set; }
        public string Email { get; set; }
        public string Contact { get; set; }
        public string gender { get; set; }
        public string HighestQualification { get; set; }
        public int User_id { get; set; }
    }
}
